create PROCEDURE obtener_info_compe(
    fecha_consulta IN DATE
)
AS
    cursor_obtener_info_compe SYS_REFCURSOR;
    nombre_juego juegos.nombre%TYPE;
    fecha_inicio competiciones.fecha_inicio%TYPE;
    fecha_fin competiciones.fecha_fin%TYPE;
    nombre_equipo equipos.nombre%TYPE;
    nombre_staff staff.nombre%TYPE;
    cantidad_jugadores NUMBER(10);
BEGIN
    open cursor_obtener_info_compe for
    SELECT j.nombre, c.fecha_inicio, c.fecha_fin, e.nombre, 
           s.nombre, COUNT(jug.cod_jugador)"Cantidad jugadores"
    INTO nombre_juego, fecha_inicio, fecha_fin, nombre_equipo, 
         nombre_staff, cantidad_jugadores
    FROM competiciones c
    JOIN juegos j ON c.cod_juego = j.cod_juego
    JOIN equipo_competicion ec ON c.cod_compe = ec.cod_competicion
    JOIN equipos e ON ec.cod_equipo = e.cod_equipo
    LEFT JOIN jugadores jug ON e.cod_equipo = jug.cod_equipo
    LEFT JOIN staff s ON e.cod_equipo = s.cod_equipo
    WHERE fecha_consulta BETWEEN c.fecha_inicio AND c.fecha_fin
    GROUP BY j.nombre, c.fecha_inicio, c.fecha_fin, e.nombre, s.nombre;
END;
/

