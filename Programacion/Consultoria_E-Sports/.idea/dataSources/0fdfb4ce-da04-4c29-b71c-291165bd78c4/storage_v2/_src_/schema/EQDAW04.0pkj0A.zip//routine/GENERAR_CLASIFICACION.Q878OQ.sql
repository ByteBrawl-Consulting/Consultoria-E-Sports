create PROCEDURE generar_clasificacion(
    codigo_competicion VARCHAR2,
    resultado OUT CLOB
)
IS
BEGIN
    -- Generar XML con la clasificación ordenada por posición
    SELECT XMLElement("Clasificacion",
               XMLAgg(
                   XMLElement("Equipo",
                       XMLForest(
                           e.nombre AS "Nombre",
                           ec.puntos AS "Puntos"
                       )
                   )
               )
           ).getClobVal()
    INTO resultado
    FROM equipos e
    JOIN equipo_competicion ec ON e.cod_equipo = ec.cod_equipo
    WHERE ec.cod_competicion = codigo_competicion
    ORDER BY ec.puntos DESC; -- Suponiendo que los equipos se clasifican por puntos
END generar_clasificacion;
/

