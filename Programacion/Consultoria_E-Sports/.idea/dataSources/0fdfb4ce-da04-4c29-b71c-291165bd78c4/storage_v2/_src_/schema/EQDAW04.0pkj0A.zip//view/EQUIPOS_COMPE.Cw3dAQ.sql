create view EQUIPOS_COMPE as
SELECT e.cod_equipo, e.nombre AS nombre_equipo, c.cod_compe, 
c.nombre AS nombre_competicion, c.cod_juego, j.nombre AS nombre_juego
FROM equipos e
JOIN equipo_competicion ec ON e.cod_equipo = ec.cod_equipo
JOIN competiciones c ON c.cod_compe = ec.cod_competicion
JOIN juegos j ON j.cod_juego = c.cod_juego
order by e.nombre
/

