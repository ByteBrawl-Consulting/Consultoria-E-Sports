create view JUEGOS_COMPE as
select j.cod_juego, j.nombre"juego", c.nombre, c.fecha_inicio, c.fecha_fin 
from juegos j 
join competiciones c 
on j.cod_juego = c.cod_juego
/

