create view JUGADORES_EQUIPO as
select j.nombre_jugador, j.nacionalidad, j.rol, j.sueldo, e.nombre "Equipo" 
from jugadores j
join equipos e
on e.cod_equipo=j.cod_equipo order by e.cod_equipo
/

