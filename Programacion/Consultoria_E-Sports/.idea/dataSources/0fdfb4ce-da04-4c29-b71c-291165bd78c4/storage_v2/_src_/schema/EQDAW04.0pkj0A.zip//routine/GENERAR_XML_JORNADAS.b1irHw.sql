create PROCEDURE generar_xml_jornadas
IS
    v_xml_data CLOB;
BEGIN
    -- Inicializar el XML
    v_xml_data := '<?xml version="1.0" encoding="UTF-8"?>' || CHR(10);
    v_xml_data := v_xml_data || '<jornadas>' || CHR(10);

    -- Consultar datos de las jornadas
    FOR jornada_rec IN (SELECT cod_jornadas, num_jornada
                        FROM jornadas)
    LOOP
        v_xml_data := v_xml_data || '    <jornada>' || CHR(10);
        v_xml_data := v_xml_data || '        <codigo_jornada>' || jornada_rec.cod_jornadas || '</codigo_jornada>' || CHR(10);
        v_xml_data := v_xml_data || '        <numero_jornada>' || jornada_rec.num_jornada || '</numero_jornada>' || CHR(10);

        -- Consultar enfrentamientos de la jornada
        FOR enfrentamiento_rec IN (SELECT e.fecha, e.hora, e.resultado,
                                           e.cod_equipo_local, e.cod_equipo_visitante,
                                           el.nombre AS equipo_local, ev.nombre AS equipo_visitante
                                    FROM enfrentamientos e
                                    JOIN equipos el ON e.cod_equipo_local = el.cod_equipo
                                    JOIN equipos ev ON e.cod_equipo_visitante = ev.cod_equipo
                                    WHERE e.cod_jornada = jornada_rec.cod_jornadas)
        LOOP
            v_xml_data := v_xml_data || '        <enfrentamiento>' || CHR(10);
            v_xml_data := v_xml_data || '            <fecha>' || TO_CHAR(enfrentamiento_rec.fecha, 'YYYY-MM-DD') || '</fecha>' || CHR(10);
            v_xml_data := v_xml_data || '            <hora>' || enfrentamiento_rec.hora || '</hora>' || CHR(10);
            v_xml_data := v_xml_data || '            <resultado>' || enfrentamiento_rec.resultado || '</resultado>' || CHR(10);
            v_xml_data := v_xml_data || '            <equipo_local>' || enfrentamiento_rec.equipo_local || '</equipo_local>' || CHR(10);
            v_xml_data := v_xml_data || '            <equipo_visitante>' || enfrentamiento_rec.equipo_visitante || '</equipo_visitante>' || CHR(10);
            v_xml_data := v_xml_data || '        </enfrentamiento>' || CHR(10);
        END LOOP;

        v_xml_data := v_xml_data || '    </jornada>' || CHR(10);
    END LOOP;

    -- Cerrar el XML
    v_xml_data := v_xml_data || '</jornadas>';

    -- Imprimir el XML
    DBMS_OUTPUT.PUT_LINE(v_xml_data);
END;
/

